package main

import "fmt"

func Public_call() {
	fmt.Println("public call, called lol.")
}
